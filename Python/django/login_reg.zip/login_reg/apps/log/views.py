from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User
# Create your views here.
def index(request):

    return render(request, 'log/index.html')

def reg(request):
    if request.method == 'POST':
        valid, data = User.objects.register(request.POST)
        if valid:
            request.session['name'] = request.POST['first_name']
            return redirect('log:success')
        else:
            for err in data:
                messages.error(request, err)
            return redirect('log:index')

def login(request):
    if request.method == 'POST':
        valid, data = User.objects.login(request.POST)
        if valid:

            user_info = User.objects.login(request.POST)
            request.session['name'] = user_info[1].first_name
            return render(request, 'log/success.html')
        else:
            for err in data:
                messages.error(request, err)
            return redirect('log:index')

def success(request):
    context = {
    'users': User.objects.all()
    }
    return render(request, 'log/success.html', context)
