from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"baseballs": League.objects.filter(sport='Baseball'),
		"womens": League.objects.filter(name__contains='Women'),
		"hockeys": League.objects.filter(sport__contains='Hockey'),
		"notfballs": League.objects.exclude(sport__contains='Football'),
		"conferences": League.objects.filter(name__contains='Conference'),
		"atlantics": League.objects.filter(name__contains='Atlantic'),
		"dallas": Team.objects.filter(location='Dallas'),
		"raptors": Team.objects.filter(team_name__contains='Raptors'),
		"citys": Team.objects.filter(location__contains='City'),
		"ts": Team.objects.filter(team_name__startswith='T'),
		"order": Team.objects.order_by('location'),
		"deorder": Team.objects.order_by('-location'),
		"cooper": Player.objects.filter(last_name='Cooper'),
		"joshua": Player.objects.filter(first_name='Joshua'),
		"jc": Player.objects.filter(last_name='Cooper').exclude(first_name='Joshua'),
		"either": Player.objects.filter(first_name='Alexander')|Player.objects.filter(first_name='Wyatt'),
		
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
