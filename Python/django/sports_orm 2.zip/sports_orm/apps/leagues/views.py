from django.shortcuts import render, redirect
from django.db.models import F, Count, Value
from .models import League, Team, Player

from . import team_maker



def index(request):

	context = {
		"baseballs": League.objects.filter(sport='Baseball'),
		"womens": League.objects.filter(name__contains='Women'),
		"hockeys": League.objects.filter(sport__contains='Hockey'),
		"notfballs": League.objects.exclude(sport__contains='Football'),
		"conferences": League.objects.filter(name__contains='Conference'),
		"atlantics": League.objects.filter(name__contains='Atlantic'),
		"dallas": Team.objects.filter(location='Dallas'),
		"raptors": Team.objects.filter(team_name__contains='Raptors'),
		"citys": Team.objects.filter(location__contains='City'),
		"ts": Team.objects.filter(team_name__startswith='T'),
		"order": Team.objects.order_by('location'),
		"deorder": Team.objects.order_by('-location'),
		"cooper": Player.objects.filter(last_name='Cooper'),
		"joshua": Player.objects.filter(first_name='Joshua'),
		"jc": Player.objects.filter(last_name='Cooper').exclude(first_name='Joshua'),
		"either": Player.objects.filter(first_name='Alexander')|Player.objects.filter(first_name='Wyatt'),
		"asc":  Team.objects.filter(league=League.objects.get(name="Atlantic Soccer Conference")),
		"bp":  Player.objects.filter(curr_team=Team.objects.get(team_name="Penguins")),
		'cbc': Team.objects.filter(league=League.objects.get(name="International Collegiate Baseball Conference")),
		'lopez': Team.objects.filter(league=League.objects.get(name="American Conference of Amateur Football")),
		'fb': Team.objects.filter(league=League.objects.filter(sport="Football")),
		'sophia': Team.objects.all(),
		'league': League.objects.all(),
		'flores': Team.objects.exclude(team_name="Roughriders"),
		'sam': Team.objects.all(),
		'mb': Team.objects.filter(team_name='Tiger-Cats'),
		'vikings': Team.objects.filter(team_name='Vikings'),
		'colts': Team.objects.exclude(team_name='Colts'),
		'josh': Team.objects.filter(league=League.objects.filter(name="Atlantic Federation of Amateur Baseball Players")),
		'anno': Team.objects.annotate(num_all_players=Count('all_players')),
		'anno2': Player.objects.annotate(num_all_teams=Count('all_teams')).order_by('num_all_teams')
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
