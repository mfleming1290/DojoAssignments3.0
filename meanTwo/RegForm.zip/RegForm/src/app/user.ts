export class User {
    first_name: string;
    last_name: string;
    email: string;
    password: string;
    password_confirm: string;
    street_address: string;
    apt_num: number;
    city: string;
    state: string;
    lucky: boolean;
}

