export class Player {
    id: Object;
    name: String;
    position: String;
    gameOne: String;
    gameTwo: String;
    gameThree: String
}
