import { Component, OnInit, OnDestroy } from '@angular/core';



@Component({
  selector: 'app-product-landing',
  templateUrl: './product-landing.component.html',
  styleUrls: ['./product-landing.component.css']
})
export class ProductLandingComponent implements OnInit, OnDestroy {


  constructor() { 

  }

 

  ngOnInit() {
    
  }

  ngOnDestroy(){
  }

}
