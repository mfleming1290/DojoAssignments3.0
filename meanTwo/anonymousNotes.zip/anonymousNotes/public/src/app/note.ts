export class Note {
    id: number;
    message: String
}
