export class Mail {
    Email: string;
    Importance: boolean;
    Subject: string;
    Content: string;
}
