export class Sayin {
    level: number;
}
