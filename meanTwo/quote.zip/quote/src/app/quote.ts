export class Quote {
    message: string;
    author: string;
    vote: number = 0;

}
