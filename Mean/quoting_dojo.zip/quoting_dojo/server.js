var express = require('express');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
var path = require('path');
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
// Require and connect to mongoose
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/dojo_quotes');

//User Schema
var UserSchema = new mongoose.Schema({
    first_name:  { type: String, required: true, minlength: 2},
    message: { type: String, required: true, maxlength: 200 },
}, {timestamps: true });
mongoose.model('User', UserSchema);
var User = mongoose.model('User')
mongoose.Promise = global.Promise;



// Routes
app.get('/quotes', function(req, res) {
    User.find({}, function(err, users) {
    if(err) {
      console.log('something went wrong');
    } else {
      console.log('got to page');
      res.render('quotes', {data: users});
    }
  })
    // This is where we will retrieve the users from the database and include them in the view page we will be rendering.
})

app.get('/', function(req, res) {
      res.render('index');

    // This is where we will retrieve the users from the database and include them in the view page we will be rendering.
})
// Add User Request
app.post('/users', function(req, res) {
  console.log("POST DATA", req.body.name);
  // create a new User with the name and age corresponding to those from req.body
  var user = new User({first_name: req.body.name, message: req.body.message});
  // Try to save that new user to the database (this is the method that actually inserts into the db) and run a callback function with an error (if any) from the operation.
  user.save(function(err) {
    // if there is an error console.log that something went wrong!
    if(err) {
      console.log('something went wrong');
      res.render('index', {title: 'you have errors!', errors: user.errors})
    } else { // else console.log that we did well and then redirect to the root route
      console.log('successfully added a user!');
      res.redirect('/quotes');
    }
  })
})
// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
    console.log("listening on port 8000");
})
